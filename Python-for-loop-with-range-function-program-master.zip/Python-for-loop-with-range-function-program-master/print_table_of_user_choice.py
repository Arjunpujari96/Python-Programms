# print a table of user choice



a = int(input("Enter number to print table"))
for i in range(1,11):
      print(i*a)
       
