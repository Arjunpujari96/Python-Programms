# python script to print table of 5

a = 5
for i in range(a, (a*10+1)):
       if i%5==0:
              print(i)
