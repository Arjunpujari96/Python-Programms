# check the the given number is positive negative or zero

a = int(input("Please Enter any number"))
if a>0:
    print("Number is positive")
elif a<0:
    print("Number is negative")
else:
    print("Number is Zero")
