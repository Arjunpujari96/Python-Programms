# check the number is divisible by 5 or not

a = int(input("Please enter a number"))
if(a%5==):
    print("Number is divisible by 5")
else:
    print("Number is not divisible by 5")
