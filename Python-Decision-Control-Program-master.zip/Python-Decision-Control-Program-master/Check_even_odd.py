#Check entered number is even or odd

a = int(input("Enter a number for check even or odd"))
if(a%2==0):
      print("Number is even")
else:
      print("Number is odd")
