#print 10 natural number
x = 1
while x<=10:
    print(x)
    x+=1
 
 """************************************************************"""
 
#print 10 natural number in reverse order
 x=10
 while x>=1:
  print(x)
  x-=1
 
 """************************************************************"""
 
# print first 10 odd number
x = 1
while x <= 20 :
    if x%2!=0:
        print(x)
        x+=1
    else:
        x+=1
        
 """************************************************************"""
 
# print first 10 even number
x = 1
while x <= 20:
    if x%2==0:
        print(x)
        x+=1
    else:
        x+=1


 
