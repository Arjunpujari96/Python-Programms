# Print N natural number value is taken from user

a = int(input("Enter Number for print natural numbers"))
b=1
while b<=a:
    print(b)
    b+=1

    
   """**************************************************************"""
#print N natural number in reverse order

a = int(input("Enter Number for print natural numbers"))
b=1
while a>=b:
    print(a)
    a-=1
