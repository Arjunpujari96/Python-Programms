# program to calculate factorial of the number


a = int(input("Enter any number"))
c=1
while a>=1:
    c = c*a
    a-=1
print("Factorial of the number is %d"%c)
