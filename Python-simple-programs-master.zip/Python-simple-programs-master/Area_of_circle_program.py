#calculate the area of circle, radious are taken from user

r = float(input("Enter the radious of the circle"))
from math import pi
A = pi*r**2
print("Area of the circle is %d" %A)
