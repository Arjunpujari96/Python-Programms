# calculate the area of triangle


b = float(input("Enter the base of the triangle"))
h = float(input("Enter the height of the triangle"))
A = 1/2*(b*h)
print("Area of the triangle is %f" %A)
