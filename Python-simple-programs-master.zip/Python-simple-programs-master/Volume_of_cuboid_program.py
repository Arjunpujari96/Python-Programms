#calculate volume of a cuboid , dimensions(float value) taken from user

l = float(input("Enter the Lenght of cuboid"))
h = float(input("Enter the height of cuboid"))
w = float(input("Enter the width of cuboid"))
V = l*h*w
print("Volume of the cuboid is %f" %V)
