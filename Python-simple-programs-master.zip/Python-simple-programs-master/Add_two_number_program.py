# Add two number(integers) input taken from user
 
  a = int(input("Enter the First number"))
  b = int(input("Enter the Second number"))
  z = a + b
  print("Addition of %d and %d is %d" %(a,b,z))
